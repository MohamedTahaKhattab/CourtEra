﻿












2023
![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.001.png)![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.002.png)![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.003.png)

Team members:

|**Name**|**ID**|
| :-: | :-: |
|Mohamed Hany|192000270|
|Mohamed Taha|192000280|
|Youssef Hossam|192000175|
|Abdullah Ashraf|192000266|
|Mohamed Heshmat|192000255|

# Table of Contents
[1.	Introduction:	4](#_toc154477718)

[2.	Specifications:	4](#_toc154477719)

[1.	Epic: User Interface Enhancement	4](#_toc154477720)

[2.	Epic: User-Friendly Navigation	4](#_toc154477721)

[3.	Epic: Single-Page Application (SPA) Implementation	5](#_toc154477722)

[4.	Epic: Authentication and Database Integration	5](#_toc154477723)

[5.	Epic: Court Information Pages	5](#_toc154477724)

[6.	Epic: Node.js Authentication APIs	5](#_toc154477725)

[7.	Epic: Responsive Design	5](#_toc154477726)

[8.	Epic: Profile Page Details	5](#_toc154477727)

[9.	Epic: Court Booking Functionality	5](#_toc154477728)

[10.	Epic: Notifications	5](#_toc154477729)

[11.	Epic: User Reviews and Ratings	5](#_toc154477730)

[12.	Epic: Social Media Integration	6](#_toc154477731)

[3.Sprint Planning	6](#_toc154477732)

[Sprint 1:	6](#_toc154477733)

[Sprint 2:	6](#_toc154477734)

[Sprint 3:	6](#_toc154477735)

[Sprint 4:	6](#_toc154477736)

[Sprint 5:	6](#_toc154477737)

[Sprint 6:	6](#_toc154477738)

[4. Design:	7](#_toc154477739)

[3.1 Class Diagram:	7](#_toc154477740)

[3.2 Use Case Diagram:	8](#_toc154477741)

[3.3 Architecture Diagram:	9](#_toc154477742)

[5. Implementation:	9](#_toc154477743)

[·	Front-end Implementation:	9](#_toc154477744)

[1.	React.js:	9](#_toc154477745)

[2.	Bootstrap:	9](#_toc154477746)

[3.	Font Awesome:	9](#_toc154477747)

[4.	React Router DOM:	9](#_toc154477748)

[5.	Axios:	9](#_toc154477749)

[6.	Formik:	10](#_toc154477750)

[7.	Yup Validation:	10](#_toc154477751)

[8.	Protected Route:	10](#_toc154477752)

[9.	HTML5, CSS3, ES6:	10](#_toc154477753)

[10.	Hooks (useState, useEffect):	10](#_toc154477754)

[·	Backend Implementation:	10](#_toc154477755)

[1.	MongoDB:	10](#_toc154477756)

[2.	ES6:	11](#_toc154477757)

[3.	Express Framework and Mongoose:	11](#_toc154477758)

[4.	Bcrypt:	11](#_toc154477759)

[5.	CORS:	11](#_toc154477760)

[·	API Endpoints:	11](#_toc154477761)

[1.	Sign In API:	11](#_toc154477762)

[2.	Sign Up API:	12](#_toc154477763)

[6.	Testing:	12](#_toc154477764)

[Test Case 1: User Registration	12](#_toc154477765)

[Inputs:	12](#_toc154477766)

[Expected Action:	12](#_toc154477767)

[Alternate Action:	12](#_toc154477768)

[Test Case 2: User Login	13](#_toc154477769)

[Inputs:	13](#_toc154477770)

[Expected Action:	13](#_toc154477771)

[Alternate Action:	13](#_toc154477772)

[7.	User Manual:	14](#_toc154477773)

[Creating an Account:	14](#_toc154477774)

[Booking a Court:	14](#_toc154477775)

[Support and Help:	14](#_toc154477776)

[8.	References:	15](#_toc154477777)



























1. # <a name="_toc154477718"></a>Introduction:
Welcome to CourTera, the ultimate hub for effortless sports reservations! 

CourTera is crafted with a deep appreciation for the fervor surrounding football and padel. 

Our platform is meticulously designed to enhance your sports encounters, offering a seamless experience for both devoted teams and enthusiastic individuals. 

Simplifying the venue and schedule booking process, CourTera allows you to concentrate on what matters most – enjoying the game. 

Join us at CourTera to unlock a realm of convenience, enabling you to reserve football and tennis facilities effortlessly. 

Step onto the field with ease and transform every match into an unforgettable experience!

![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.004.jpeg)
1. # <a name="_toc154477719"></a>Specifications:
1. ## <a name="_toc154477720"></a>Epic: User Interface Enhancement
- **User Story:** As a user, I want the website to have an intuitive and friendly UI/UX.
- **Acceptance Criteria:** The interface should be visually appealing, easy to navigate, and provide a seamless user experience
1. ## <a name="_toc154477721"></a>Epic: User-Friendly Navigation
- **User Story:** As a user, I want an easily navigable menu for seamless exploration of football and padel options.
- **Acceptance Criteria:** Implement a clear and user-friendly navigation menu for intuitive access to different sections of the website.
1. ## <a name="_toc154477722"></a>Epic: Single-Page Application (SPA) Implementation
- **User Story:** As a user, I want the website to apply the single-page application concept using React.js.
- **Acceptance Criteria:** The website should load content dynamically without full page reloads, providing a smooth and efficient user experience.
1. ## <a name="_toc154477723"></a>Epic: Authentication and Database Integration
- **User Story:** As a user, I want to authenticate using secure credentials stored in the database.
- **Acceptance Criteria:** Implement user authentication using secure methods and connect it to the database.
1. ## <a name="_toc154477724"></a>Epic: Court Information Pages
- **User Story:** As a user, I want separate pages for football and padel with detailed information about each court.
- **Acceptance Criteria:** The website should have dedicated pages for football and padel courts, displaying relevant details, such as availability, amenities, and booking options.
1. ## <a name="_toc154477725"></a>Epic: Node.js Authentication APIs
- **User Story:** As a developer, I want to implement authentication APIs using Node.js.
- **Acceptance Criteria:** Develop APIs for user registration, login, and token management using Node.js, ensuring secure communication between the front-end and back-end.
1. ## <a name="_toc154477726"></a>Epic: Responsive Design
- **User Story:** As a user, I want the website to be responsive on different screen sizes.
- **Acceptance Criteria:** The website should adapt its layout and design to provide an optimal viewing experience on various devices, including desktops, tablets, and mobile phones.
1. ## <a name="_toc154477727"></a>Epic: Profile Page Details
- **User Story:** As a user, I want to view details on my profile page.
- **Acceptance Criteria:** Users should be able to access and view their profile details, including personal information and booking history.
1. ## <a name="_toc154477728"></a>Epic: Court Booking Functionality
- **User Story:** As a user, I want the ability to book football and padel courts easily.
- **Acceptance Criteria:** Integrate a booking system that allows users to select available time slots for their preferred courts, providing confirmation and receipt.
1. ## <a name="_toc154477729"></a>Epic: Notifications
- **User Story:** As a user, I want to receive notifications for successful bookings and other relevant updates.
- **Acceptance Criteria:** Implement a notification system to keep users informed about their booking status and any important announcements.
1. ## <a name="_toc154477730"></a>Epic: User Reviews and Ratings
- **User Story:** As a user, I want to view reviews and ratings for each football and padel court.
- **Acceptance Criteria:** Create a system for users to leave reviews and ratings, and display an average rating for each court.
1. ## <a name="_toc154477731"></a>Epic: Social Media Integration
- **User Story:** As a user, I want the option to share my booking or reviews on social media platforms.
- **Acceptance Criteria:** Integrate social media sharing functionality to allow users to share their experiences and activities on the platform.
# <a name="_toc154477732"></a>3.Sprint Planning
## <a name="_toc154477733"></a>Sprint 1:
- **Task 1:** Design UI/UX for the website.
- **Task 2:** Set up a React.js project for the single-page application.
- **Task 3:** Implement basic authentication functionality on the front-end.
## <a name="_toc154477734"></a>Sprint 2:
- **Task 4:** Develop separate pages for football and padel courts.
- **Task 5:** Design and implement a responsive layout for the website.
## <a name="_toc154477735"></a>Sprint 3:
- **Task 6:** Implement authentication APIs using Node.js.
- **Task 7:** Create profile pages and integrate them with the authentication system.
## <a name="_toc154477736"></a>Sprint 4:
- **Task 8:** Design and implement a user-friendly navigation menu.
- **Task 9:** Develop court booking functionality with a user-friendly interface.
## <a name="_toc154477737"></a>Sprint 5:
- **Task 10:** Implement a notification system for booking updates.
- **Task 11:** Integrate user reviews and ratings functionality.
## <a name="_toc154477738"></a>Sprint 6:
- **Task 12:** Integrate social media sharing features.
- **Task 13:** Perform testing and bug fixes for the implemented features.
# <a name="_toc154477739"></a>4. Design:
## <a name="_toc154477740"></a>3.1 Class Diagram:
![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.005.png)
## <a name="_toc154477741"></a>3.2 Use Case Diagram:
![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.006.png)
## <a name="_toc154477742"></a>3.3 Architecture Diagram:
![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.007.png)
# <a name="_toc154477743"></a>5. Implementation:
- ## <a name="_toc154477744"></a>Front-end Implementation:
1. ### <a name="_toc154477745"></a>React.js:
- We used React.js to apply single page application concept and because react depend on different libraries and modules.
- Components: react virtual dom.
1. ### <a name="_toc154477746"></a>Bootstrap:
- We used bootstrap for navbar component and modified it to be compatible with the design.
1. ### <a name="_toc154477747"></a>Font Awesome:
- We used font Awesome icons in social media icons in footer , profile icon and icons in navbar.
1. ### <a name="_toc154477748"></a>React Router DOM:
- React-router-dom made the navigation between pages easier with no refresh.
- Example: when user login successfully the website navigates him to home page.
1. ### <a name="_toc154477749"></a>Axios:
- Axios post the data in form of object to the backend to check the database if exist or not.
- Example: in sign in we used axios.post method to send email and password to backend as an Object.
1. ### <a name="_toc154477750"></a>Formik:
- Formik has some events to handle form changes like handle bluer and handle submit which handle the submit of forms by taking the entered data in input fields and send it to submit function.
- Example: formik has functions to handle any change in the form ( formik.handleChange ) so no need to make it manualy.
1. ### <a name="_toc154477751"></a>Yup Validation:
- We used Yup built-in methods to check the inputs by applying some conditions on these methods.
- Examples: one of the rules we used is the rule of email in forms which is ( required rule ) and the email should contain @ sign.
1. ### <a name="_toc154477752"></a>Protected Route:
- It is a user defined module with if condition to check if the user logged in or not to navigate him to a specific page.
- Example: The route that required an authentication is profile module .
1. ### <a name="_toc154477753"></a>HTML5, CSS3, ES6:
- Html5 used to build the construction of the website pages.
- css3 used to apply the design.
- Es6 is a version of java script which helps us to make the functions of the website.
- Example: we used semantic tags which produced in Html5.
1. ### <a name="_toc154477754"></a>Hooks (useState, useEffect):
- Use state is used to initiate variables. 
- use effect is used with component didmount function.
- ## <a name="_toc154477755"></a>Backend Implementation:
1. ### <a name="_toc154477756"></a>MongoDB:
- Depend on the type of data and the relation between them, we used user collections.

![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.008.jpeg)
1. ### <a name="_toc154477757"></a>ES6:
- We used ES6 to import files and modules.
1. ### <a name="_toc154477758"></a>Express Framework and Mongoose:
- Express make the code shortest and easier , Mongoose contain methods to interact with mongo.
- Example: router.post('/signUp',UC.signUp);.
1. ### <a name="_toc154477759"></a>Bcrypt:
- Bcrypt has function to hash passwords ( hashSync ) and it take the passwords from the login forms and hash them again then compare them using ( compareSync ).
1. ### <a name="_toc154477760"></a>CORS:
- We used CORS to be able to use the API link in front end.
- ## <a name="_toc154477761"></a>API Endpoints:
1. ### <a name="_toc154477762"></a>Sign In API:
![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.009.jpeg)

![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.010.jpeg)

1. ### <a name="_toc154477763"></a>Sign Up API:
![C:\Users\Abdullah Ashraf\AppData\Local\Packages\5319275A.WhatsAppDesktop_cv1g1gvanyjgm\TempState\D6B572A5481F1708192A1DC09DED07FE\WhatsApp Image 2023-12-26 at 03.38.25_5e01595c.jpg](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.011.jpeg)

![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.012.jpeg)
1. # <a name="_toc154477764"></a>Testing:
## <a name="_toc154477765"></a>Test Case 1: User Registration
### <a name="_toc154477766"></a>Inputs:
- **User Name:** Mohamed Heshmat
- **User Phone:** 01010446753
- **User Email:** heshmat@gmail.com
- **User Password:** mohamed1234
### <a name="_toc154477767"></a>Expected Action:
- The system should navigate to the login page.
### <a name="_toc154477768"></a>Alternate Action:
- If the user already exists in the database, the system should send a response indicating the existence of the user.

![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.013.jpeg)
## <a name="_toc154477769"></a>Test Case 2: User Login
### <a name="_toc154477770"></a>Inputs:
- **User Email:** heshmat@gmail.com
- **User Password:** mohamed1234
### <a name="_toc154477771"></a>Expected Action:
- The system should navigate to the home page.
### <a name="_toc154477772"></a>Alternate Action:
- If the user does not have an account, the database should send an error message to inform the user to register.

![](Aspose.Words.b3656698-c500-4fea-b760-5eb41cf8a1e0.014.jpeg)

1. # <a name="_toc154477773"></a>User Manual:
## <a name="_toc154477774"></a>Creating an Account:
1. **Go to Registration Page:**
   1. Navigate to the Registration page by clicking on the "Register" or "Create Account" link in the navigation menu.
1. **Fill the Input Fields:**
   1. Complete the required fields, including User Name, Phone, Email, and Password.
   1. Ensure that your password meets the specified criteria, if any (e.g., minimum length, special characters).
1. **Press Register:**
   1. Click the "Register" button to submit your registration information.
   1. If successful, you should be redirected to the login page.
## <a name="_toc154477775"></a>Booking a Court:
1. **Go to Courts:**
   1. Access the "Courts" section by clicking on the corresponding link in the navigation menu.
1. **Choose the Type of Court:**
   1. Select the type of court you want to book (e.g., football, padel).
1. **Hover Over Any Court Card:**
   1. Hover over the card representing the court you wish to book to view additional details.
1. **Press Book:**
   1. Click the "Book" button to proceed with the booking.
   1. Follow any on-screen prompts to choose a date and time for your reservation.
## <a name="_toc154477776"></a>Support and Help:
1. **Scroll Down in Home Page Until Reaching the Contact Form:**
   1. Navigate to the bottom of the Home page to find the contact form.
1. **Write Your Name, Email, and the Message:**
   1. Fill in your Name and Email in the designated fields.
   1. Write your message or describe the issue you need help with in the provided text area.
1. **Press Submit:**
   1. Click the "Submit" button to send your inquiry to the support team.
   1. Expect a response from the CourTera support team to the provided email address.

1. # <a name="_toc154477777"></a>References:
- <https://app.diagrams.net/>
- <https://khattabprojects.atlassian.net/jira/software/projects/COR/boards/2/backlog>
- <https://github.com/MohamedTahaKhattab/CourtEra>
- <https://www.npmjs.com>

**15 **|** Page

